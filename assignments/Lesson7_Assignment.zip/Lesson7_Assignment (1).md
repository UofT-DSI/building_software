﻿**Lesson 7 Assignment**

**Overview:**

Use the New York Times Article Search API to retrieve articles on a topic of interest and explore trends in related coverage over time.

**Tasks:**

1. Register for a New York Times developer account and review the Article Search API docs.
1. Use the search and filter parameters to retrieve article metadata on a specific topic (technology, politics, business etc) over a multi-year period using the API. Feel free to replace ‘climate change’ with a different topic.

url = 'https://api.nytimes.com/svc/search/v2/articlesearch.json' params = {'api-key': YOUR\_KEY,

'q': 'climate change',

'begin\_date': '20180101',

'end\_date': '20221231'}

response = requests.get(url, params)

articles = response.json()['response']['docs']

3. Extract key attributes from the article snippets in the API response:

for a in articles:

headline = a['headline']['main'] date = a['pub\_date']

section = a['section\_name'] keywords = a['keywords']

4. Track the volume of articles matching query by year and visualize trend with a timeline chart.

   years = {}

for a in articles:

year = a['pub\_date'].split('-')[0] if year in years:

years[year] += 1

else:

years[year] = 1

import matplotlib.pyplot as plt

years = [2018, 2019, 2020, 2021, 2022] counts = [years[y] for y in years]

plt.bar(years, counts)

plt.title("Climate Change Coverage by Year") plt.xlabel("Year")

plt.ylabel("Articles")

plt.show()

5. Write up your observations on coverage of this topic based on analyzing search results
- Did story trends align with major events in the subject?
- What areas got more or less coverage over time?
